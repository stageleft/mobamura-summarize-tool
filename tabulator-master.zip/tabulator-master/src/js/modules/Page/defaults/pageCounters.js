import rows from './pageCounters/rows.js';
import pages from './pageCounters/pages.js';


export default {
	rows:rows,
	pages:pages,
};